import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import jwt_decode from 'jwt-decode'

const DashboardPage = (props) => {
  const nameRef = React.createRef();
  const [chatrooms, setChatrooms] = React.useState([]);
  const getChatrooms = () => {
    axios
      .get("http://localhost:5000/chatroom", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("CC_Token"),
        },
      })
      .then((response) => {
        setChatrooms(response.data);
      })
      .catch((err) => {
        setTimeout(getChatrooms, 3000);
      });
  };

  React.useEffect(() => {
    getChatrooms();
    // eslint-disable-next-line
  }, []);

  const handleSubmit=(props)=>{
    
    const token=localStorage.CC_Token
       
    const name = nameRef.current.value;

    axios
    .post("http://localhost:5000/chatroom",{
      
      headers: {
        Authorization: "Bearer " + localStorage.getItem("CC_Token"),
      },name
      
    })
    .then((response) => {
      
    })
    .catch((err) => {
     
    });
      }
    
  return (
    <div className="card">
      <div className="cardHeader">Chatrooms</div>
      <div className="cardBody">
        <div className="inputGroup">
          <label htmlFor="chatroomName">Chatroom Name</label>
          <input
          type="text"
          name="name"
          id="name"
         
          ref={nameRef}
            placeholder="ChatterBox Nepal"
          />
        </div>
      </div>
      <button onClick={handleSubmit} >Create Chatroom</button>
      <div className="chatrooms">
        {chatrooms.map((chatroom) => (
          <div key={chatroom._id} className="chatroom">
            <div>{chatroom.name}</div>
            <Link to={"/chatroom/" + chatroom._id}>
              <div className="join">Join</div>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
};



export default DashboardPage;